package com.hoangkimgia.cellphone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CellphoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(CellphoneApplication.class, args);
	}

}
