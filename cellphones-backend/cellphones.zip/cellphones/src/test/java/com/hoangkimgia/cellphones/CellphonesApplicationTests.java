package com.hoangkimgia.cellphones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CellphonesApplicationTests {

	@Test
	void contextLoads() {
	}

}
