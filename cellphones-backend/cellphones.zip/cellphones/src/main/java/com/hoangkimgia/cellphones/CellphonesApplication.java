package com.hoangkimgia.cellphones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CellphonesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CellphonesApplication.class, args);
	}

}
